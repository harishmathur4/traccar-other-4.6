package com.example.cucumber.tester;

import com.google.common.hash.BloomFilter;
        import com.google.common.hash.Funnels;
        import java.nio.charset.StandardCharsets;
        import java.util.*;

public class TradeRuleMatcherNUmbers {

    // Bloom filter to store rule attributes
    private static final BloomFilter<String> bloomFilter = BloomFilter.create(
            Funnels.stringFunnel(StandardCharsets.UTF_8),
            1000, // Expected attributes
            0.01  // 1% false positive rate
    );

    // Mapping of rules and their attributes
    private static final Map<String, Set<String>> ruleStore = new HashMap<>();

    // Load rules into Bloom Filter
    public static void loadRules(Map<String, Set<String>> rules) {
        for (Map.Entry<String, Set<String>> entry : rules.entrySet()) {
            String ruleName = entry.getKey();
            Set<String> attributes = entry.getValue();

            ruleStore.put(ruleName, attributes);
            for (String attr : attributes) {
                bloomFilter.put(attr);  // Store each attribute in the Bloom Filter
            }
        }
    }

    // Check which rules fully match all trade attributes
    public static void matchTrade(Set<String> tradeAttributes) {
        Set<String> possibleRules = new HashSet<>();

        // Step 1: Use Bloom Filter to eliminate rules early
        for (String attr : tradeAttributes) {
            if (!bloomFilter.mightContain(attr)) {
                System.out.println("Trade attribute " + attr + " not found in any rule. Skipping.");
                return;  // If any trade attribute is missing, no rule can fully match
            }
        }

        // Step 2: Identify possible rules that contain all trade attributes
        for (Map.Entry<String, Set<String>> entry : ruleStore.entrySet()) {
            String rule = entry.getKey();
            Set<String> ruleAttributes = entry.getValue();

            // Check if the rule contains all trade attributes
            if (ruleAttributes.containsAll(tradeAttributes)) {
                possibleRules.add(rule);
            }
        }

        // Step 3: Print matched rules or indicate no match
        if (!possibleRules.isEmpty()) {
            System.out.println("Trade fully matches rules: " + possibleRules);
        } else {
            System.out.println("No rule fully matches the trade.");
        }
    }

    public static void main(String[] args) {
        // Define rules with multiple attributes
        Map<String, Set<String>> rules = new HashMap<>();
        rules.put("Rule A", new HashSet<>(Arrays.asList("1", "2", "3", "4")));   // Needs 1,2,3,4
        rules.put("Rule B", new HashSet<>(Arrays.asList("5", "6", "7")));       // Needs 5,6,7
        rules.put("Rule C", new HashSet<>(Arrays.asList("8", "9", "10")));      // Needs 8,9,10

        // Load rules into Bloom Filter
        loadRules(rules);

        // Test Case 1: Should NOT match since only part of Rule A or C attributes are provided
        matchTrade(new HashSet<>(Arrays.asList("1", "8")));   // ❌ No full match

        // Test Case 2: Should match Rule A (since it contains 1,2,3,4)
        matchTrade(new HashSet<>(Arrays.asList("1", "2", "3", "4")));  // ✅ Matches Rule A

        // Test Case 3: Should match Rule C (since it contains 8,9,10)
        matchTrade(new HashSet<>(Arrays.asList("8", "9", "10")));  // ✅ Matches Rule C

        // Test Case 4: No match (attributes not in any rule)
        matchTrade(new HashSet<>(Arrays.asList("11", "12")));  // ❌ No match
    }
}
