package com.example.cucumber.tester;
import com.google.common.hash.BloomFilter;
import com.google.common.hash.Funnels;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class TradeRuleMatcher {

    // Bloom filter to store rule keys
    private static final BloomFilter<String> ruleFilter = BloomFilter.create(
            Funnels.stringFunnel(StandardCharsets.UTF_8),
            1_000_000, // Expected rules
            0.01 // 1% false positive rate
    );

    // Simulated rule storage (mapping rule keys to actual rule logic)
    private static final Map<String, String> ruleStore = new HashMap<>();

    // Load rules into the Bloom filter
    public static void loadRules(List<String> rules) {
        for (String ruleKey : rules) {
            ruleFilter.put(ruleKey);
            ruleStore.put(ruleKey, "Rule logic for " + ruleKey);
        }
    }

    // Check if a trade matches any rule using the Bloom Filter
    public static void matchTrade(String tradeAttribute) {
        if (ruleFilter.mightContain(tradeAttribute)) {
            // Bloom filter says it *might* be a match → Check the actual rule store
            if (ruleStore.containsKey(tradeAttribute)) {
                System.out.println("Trade matches rule: " + ruleStore.get(tradeAttribute));
            } else {
                System.out.println("False positive, trade does not match any rule.");
            }
        } else {
            System.out.println("Trade does not match any rule, skipping.");
        }
    }

    public static void main(String[] args) {
        // Example rule keys based on trade attributes (e.g., tradeType-region-productCode)
        List<String> rules = Arrays.asList("FX-EURO-STOCK", "BOND-US-TREASURY", "CRYPTO-BTC-ETF");

        // Load rules into Bloom Filter
        loadRules(rules);

        // Example trades being checked
        matchTrade("FX-EURO-STOCK");      // Should match
        matchTrade("BOND-US-TREASURY");   // Should match
        matchTrade("FX-ASIA-STOCK");      // Should be skipped
        matchTrade("CRYPTO-ETH-ETF");     // Should be skipped
    }
}
