package com.example.cucumber.kafka;

import io.cucumber.java.AfterAll;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;

public class LogsCleaner {

    @AfterAll
    public static void tearDownKafka() {
        System.out.println("Stopping Embedded Kafka and cleaning up logs...");
        EmbeddedKafkaManager.stopKafka();
        // Wait a bit to ensure file handles are released
        try {
            Thread.sleep(2000);
        } catch (InterruptedException ignored) {}

        deleteKafkaLogs();
    }
    public static void deleteKafkaLogs() {
        File projectRoot = new File(System.getProperty("user.dir"));

        // Find all kafka-logs* and temp-delete-* directories
        File[] logDirs = projectRoot.listFiles((dir, name) -> name.matches("(kafka-logs.*|temp-delete-.*)"));

        if (logDirs != null) {
            for (File dir : logDirs) {
                System.out.println("Attempting to delete: " + dir.getAbsolutePath());

                if (forceDelete(dir)) {
                    System.out.println("Deleted: " + dir.getAbsolutePath());
                } else {
                    System.err.println("Failed to delete: " + dir.getAbsolutePath());
                }
            }
        }
    }

    private static boolean forceDelete(File dir) {
        if (!dir.exists()) {
            return true; // Already deleted
        }

        try {
            // Retry deletion if necessary
            for (int i = 0; i < 3; i++) {
                deleteDirectory(dir);

                if (!dir.exists()) {
                    return true;
                }

                // Wait before retrying
                Thread.sleep(1000);
            }

            return !dir.exists();
        } catch (InterruptedException ignored) {
            return false;
        }
    }

    private static void deleteDirectory(File dir) {
        if (dir.exists() && dir.isDirectory()) {
            File[] files = dir.listFiles();
            if (files != null) {
                Arrays.stream(files).forEach(LogsCleaner::deleteDirectory);
            }
        }
        try {
            Files.deleteIfExists(dir.toPath());
        } catch (IOException e) {
            System.err.println("Error deleting " + dir.getAbsolutePath() + ": " + e.getMessage());
        }
    }
}