package com.example.cucumber.config;


import org.springframework.context.annotation.Configuration;

@Configuration
public class TestConfig {
}
