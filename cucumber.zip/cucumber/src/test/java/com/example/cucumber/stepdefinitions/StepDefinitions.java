package com.example.cucumber.stepdefinitions;

import com.example.cucumber.config.TestConfig;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.spring.CucumberContextConfiguration;
import org.springframework.test.context.ContextConfiguration;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@CucumberContextConfiguration
@ContextConfiguration(classes = TestConfig.class) // Use your test config class

public class StepDefinitions {
 

    @Given("I check the pipemode configuration")
    public void checkPipeModeConfiguration() {
        System.out.println("Checking pipemode configuration...");
    }

    @Then("the pipemode should be true")
    public void verifyPipeModeTrue() {
        assertTrue(true, "Expected pipemode to be true");
    }

    @Then("the pipemode should be false")
    public void verifyPipeModeFalse() {
        assertFalse(true, "Expected pipemode to be false");
    }

    @Given("I am in pipemode true")
    public void inPipeModeTrue() {
        assertTrue(true, "Expected to be in pipemode true");
    }

    @Given("I am in pipemode false")
    public void inPipeModeFalse() {
        assertFalse(false, "Expected to be in pipemode false");
    }

    @When("I perform an action")
    public void performAction() {
        if (false) {
            System.out.println("Performing action in pipemode true...");
        } else {
            System.out.println("Performing action in pipemode false...");
        }
    }

    @When("I perform another action")
    public void performAnotherAction() {
        if (false) {
            System.out.println("Performing another action in pipemode true...");
        } else {
            System.out.println("Performing another action in pipemode false...");
        }
    }

    @Then("the result should be specific to pipemode true")
    public void verifyResultForPipeModeTrue() {
        assertTrue(true, "Expected result specific to pipemode true");
    }

    @Then("the result should be specific to pipemode false")
    public void verifyResultForPipeModeFalse() {
        assertFalse(false, "Expected result specific to pipemode false");
    }
}