package com.example.cucumber.stepdefinitions;

import com.example.cucumber.config.TestConfig;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.spring.CucumberContextConfiguration;
import org.springframework.test.context.ContextConfiguration;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import java.time.Duration;
import java.util.Collections;
import java.util.Properties;
import static org.junit.jupiter.api.Assertions.assertEquals;

@CucumberContextConfiguration
@ContextConfiguration(classes = TestConfig.class) // Use your test config class

public class StepDefinitions {

    private static final String TOPIC = "test-topic";
    private static final String BOOTSTRAP_SERVERS = "127.0.0.1:9092";
    private static String receivedMessage;
 

    @Given("I check the pipemode configuration")
    public void checkPipeModeConfiguration() {
        System.out.println("Checking pipemode configuration...");
    }

    @Then("the pipemode should be true")
    public void verifyPipeModeTrue() {
        assertTrue(true, "Expected pipemode to be true");
    }

    @Then("the pipemode should be false")
    public void verifyPipeModeFalse() {
        assertFalse(true, "Expected pipemode to be false");
    }

    @Given("I am in pipemode true")
    public void inPipeModeTrue() {
        assertTrue(true, "Expected to be in pipemode true");
    }

    @Given("I am in pipemode false")
    public void inPipeModeFalse() {
        assertFalse(false, "Expected to be in pipemode false");
    }

    @When("I perform an action")
    public void performAction() {
        if (false) {
            System.out.println("Performing action in pipemode true...");
        } else {
            System.out.println("Performing action in pipemode false...");
        }
    }

    @When("I perform another action")
    public void performAnotherAction() {
        if (false) {
            System.out.println("Performing another action in pipemode true...");
        } else {
            System.out.println("Performing another action in pipemode false...");
        }
    }

    @Then("the result should be specific to pipemode true")
    public void verifyResultForPipeModeTrue() {
        assertTrue(true, "Expected result specific to pipemode true");
    }

    @Then("the result should be specific to pipemode false")
    public void verifyResultForPipeModeFalse() {
        assertFalse(false, "Expected result specific to pipemode false");
    }

    @Given("I send a message {string} to {string}")
    public void iSendMessageToTopic(String message, String topic) {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());

        try (KafkaProducer<String, String> producer = new KafkaProducer<>(props)) {
            ProducerRecord<String, String> record = new ProducerRecord<>(topic, message);
            producer.send(record, (metadata, exception) -> {
                if (exception == null) {
                    System.out.println("✅ Sent: " + message);
                } else {
                    exception.printStackTrace();
                }
            });
        }
    }

    @Then("I should receive the message {string} from {string}")
    public void iShouldReceiveMessage(String expectedMessage, String topic) {
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, "test-group");
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");

        try (KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props)) {
            consumer.subscribe(Collections.singletonList(topic));

            System.out.println("🔍 Waiting for messages...");
            ConsumerRecords<String, String> records = consumer.poll(Duration.ofSeconds(5));
            for (ConsumerRecord<String, String> record : records) {
                receivedMessage = record.value();
                System.out.println("📥 Received: " + receivedMessage);
            }
        }

        assertEquals(expectedMessage, receivedMessage, "Received message does not match expected!");
    }
}