package com.example.cucumber.kafka;

import kafka.server.KafkaConfig;
import kafka.server.KafkaServer;
import org.apache.kafka.common.utils.Time;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.NewTopic;

import java.io.File;
import java.util.Collections;
import java.util.Properties;

import org.apache.curator.test.TestingServer;
import org.apache.kafka.clients.admin.*;


public class EmbeddedKafkaManager {
    private static TestingServer zookeeper;
    private static KafkaServer kafkaServer;
    private static File kafkaLogDir;

    public static void startKafka() throws Exception {
        kafkaLogDir = new File(System.getProperty("java.io.tmpdir"), "embedded-kafka-logs");
        kafkaLogDir.mkdirs();

        zookeeper = new TestingServer(2181, true);
        System.out.println("🟢 Embedded Zookeeper started at " + zookeeper.getConnectString());

        kafkaServer = new KafkaServer(new KafkaConfig(getKafkaProperties()), Time.SYSTEM, scala.Option.empty(), false);
        kafkaServer.startup();
        System.out.println("🟢 Embedded Kafka started at 127.0.0.1:9092");
    }

    public static void stopKafka() {
        try {
            if (kafkaServer != null) {
                kafkaServer.shutdown();
                System.out.println("🔴 Kafka Stopped");
            }
            if (zookeeper != null) {
                zookeeper.close();
                System.out.println("🔴 Zookeeper Stopped");
            }
            // Clean up logs
            if (kafkaLogDir != null && kafkaLogDir.exists()) {
                deleteDirectory(kafkaLogDir);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void createTopic(String topic, int partitions, short replicationFactor) {
        Properties config = new Properties();
        config.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, "127.0.0.1:9092");
        config.put("offsets.topic.replication.factor", "1"); // ✅ Ensure `__consumer_offsets` is created with 1 replica

        try (AdminClient adminClient = AdminClient.create(getKafkaProperties())) {
            NewTopic newTopic = new NewTopic(topic, partitions, (short) 1);
            adminClient.createTopics(Collections.singletonList(newTopic)).all().get();
            System.out.println("🟢 Created Topic: " + topic);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private static void deleteDirectory(File dir) {
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                deleteDirectory(file);
            }
        }
        dir.delete();
    }

    private static Properties getKafkaProperties() {
        Properties props = new Properties();
        props.put("zookeeper.connect", zookeeper.getConnectString());
        // Set Kafka log directory inside project root
        String kafkaLogDir = System.getProperty("user.dir") + "/kafka-logs-" + System.currentTimeMillis();
        props.put("log.dirs", kafkaLogDir);

        // Set up a single-broker Kafka instance
        props.put("broker.id", "1");
        props.put("listeners", "PLAINTEXT://127.0.0.1:9092");

        // The missing bootstrap.servers configuration
        props.put("bootstrap.servers", "127.0.0.1:9092");

        // Topic and log settings
        props.put("auto.create.topics.enable", "true");
        props.put("log.retention.hours", "1");
        props.put("log.segment.bytes", "104857600");
        props.put("delete.topic.enable", "true");
        props.put("transaction.state.log.replication.factor","1");
        props.put("transaction.state.log.min.isr","1");

        props.put("group.initial.rebalance.delay.ms", "0");  // Speeds up group creation
        props.put("offsets.topic.replication.factor", "1");  // Ensure single broker setup
        props.put("offsets.topic.num.partitions", "1");      // Ensure single partition
        props.put("offsets.topic.enable", "false");          // 🛠️ Prevents `__consumer_offsets` creation


        props.put("num.partitions", "1");
        props.put("min.insync.replicas", "1");


        return props;
    }


}


