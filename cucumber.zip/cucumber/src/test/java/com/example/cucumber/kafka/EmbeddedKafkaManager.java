package com.example.cucumber.kafka;

import kafka.server.KafkaConfig;
import kafka.server.KafkaServer;
import org.apache.kafka.common.utils.Time;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.NewTopic;

import java.io.File;
import java.util.Collections;
import java.util.Properties;

import org.apache.curator.test.TestingServer;
import org.apache.kafka.clients.admin.*;


public class EmbeddedKafkaManager {
    private static TestingServer zookeeper;
    private static KafkaServer kafkaServer;
    private static File kafkaLogDir;

    public static void startKafka() throws Exception {
        kafkaLogDir = new File(System.getProperty("java.io.tmpdir"), "embedded-kafka-logs");
        kafkaLogDir.mkdirs();

        zookeeper = new TestingServer(2181, true);
        System.out.println("🟢 Embedded Zookeeper started at " + zookeeper.getConnectString());

        Properties kafkaProps = new Properties();
        kafkaProps.put("log.dirs", kafkaLogDir.getAbsolutePath()); // Set log directory
        kafkaProps.put("zookeeper.connect", zookeeper.getConnectString());
        kafkaProps.put("broker.id", "1");
        kafkaProps.put("log.dirs", "kafka-logs-" + System.currentTimeMillis());
        kafkaProps.put("listeners", "PLAINTEXT://127.0.0.1:9092");
        kafkaProps.put("auto.create.topics.enable", "true");

        kafkaServer = new KafkaServer(new KafkaConfig(kafkaProps), Time.SYSTEM, scala.Option.empty(), false);
        kafkaServer.startup();
        System.out.println("🟢 Embedded Kafka started at 127.0.0.1:9092");
    }

    public static void stopKafka() {
        try {
            if (kafkaServer != null) {
                kafkaServer.shutdown();
                System.out.println("🔴 Kafka Stopped");
            }
            if (zookeeper != null) {
                zookeeper.close();
                System.out.println("🔴 Zookeeper Stopped");
            }
            // Clean up logs
            if (kafkaLogDir != null && kafkaLogDir.exists()) {
                deleteDirectory(kafkaLogDir);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void createTopic(String topic, int partitions, short replicationFactor) {
        Properties config = new Properties();
        config.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, "127.0.0.1:9092");
        try (AdminClient admin = AdminClient.create(config)) {
            NewTopic newTopic = new NewTopic(topic, partitions, replicationFactor);
            admin.createTopics(Collections.singletonList(newTopic)).all().get();
            System.out.println("🟢 Created Topic: " + topic);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void deleteDirectory(File dir) {
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                deleteDirectory(file);
            }
        }
        dir.delete();
    }
}


