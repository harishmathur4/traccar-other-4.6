package com.example.cucumber;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CucumberApplicationTests {

	@Test
	void contextLoads() {
	}

}
