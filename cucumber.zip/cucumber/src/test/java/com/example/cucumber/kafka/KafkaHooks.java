package com.example.cucumber.kafka;

import io.cucumber.java.Before;
import io.cucumber.java.After;

public class KafkaHooks {
    @Before
    public void setupKafka() throws Exception {
        EmbeddedKafkaManager.startKafka();
        EmbeddedKafkaManager.createTopic("test-topic", 1, (short) 1);
    }

    @After
    public void teardownKafka() {
        EmbeddedKafkaManager.stopKafka();
    }
}
